# 使用安全函数编程

## 1、字符串拷贝
strcpy
memcpy
strncpy

## 2、字符串转整型数字
不使用atoi，可以使用itoa


## 3、字符串相等比较
## 4、字符串格式转换
sprintf
snprintf

## 5、
## 6、
## 7、
## 8、
## 9、


