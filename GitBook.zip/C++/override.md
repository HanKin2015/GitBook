# override、overwrite和overload区别



个人认为overwrite只是有些人把重写翻译回英文的时候翻译错了，重写就是override。

Override是方法的覆盖

overload是方法的重载

Overwrite是方法的重写