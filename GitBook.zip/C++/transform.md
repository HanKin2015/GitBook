
# 类型转换小结

## 1、string转int

atoi

## 2、int转char*

sprintf()

```
char buffer[BUFSIZ] = {0};
snprintf(buffer, sizeof(buffer),)

```



