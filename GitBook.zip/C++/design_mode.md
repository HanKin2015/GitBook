# 设计模式

https://mp.weixin.qq.com/s/tNxgu2H2xfc1eI23gCGMfw

## 1、









