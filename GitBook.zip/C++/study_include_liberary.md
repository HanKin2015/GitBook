# C++/C编程库中常用函数

# 'close' was not declared in this scope
#include <unistd.h>

# 'inet_pton' was not declared in this scope
#include <arpa/inet.h>



