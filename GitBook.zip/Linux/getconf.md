# getconf命令


getconf LONG_BIT
