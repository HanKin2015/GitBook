# Linux入门学习

## 1、tweak工具
ubuntu左侧叫做dock，一般有个优化工具叫做tweak。也可以在桌面背景设置-》行为。

topicons plus

## 2、Ubuntu用户都应该安装的4个Linux应用
Synaptic（新立得软件包管理器），卓越的包管理器
Mainline，在 Ubuntu 中始终拥有最新的内核
BleachBit，Ubuntu Ccleaner 的替代品
Kodi：触手可及的多媒体中心

## 3、开机自动获取ip地址
编辑 /etc/sysconfig/network-scripts/ifcfg-eth0 让系统启动时自动获取IP地址：

## 4、使用root用户登录系统，执行以下命令
$ vi /etc/sysconfig/network-scripts/ifcfg-eth0

将 ONBOOT=no 改为 ONBOOT=yes，保存文件后，执行以下命令重启网卡

$ service network restart

dhclient
ifup
ip addr

## 5、apt-get -y install中的-y是什么意思?
是同意的意思。没有 -y的命令也可以执行，系统会提示你是否安装，输入y，回车，就会安装了
apt-get -y install这个指令则是跳过系统提示，直接安装。

## 6、rm -rf  dir     

- r是递归文件夹
- f 忽略不存在的文件，从不给出提示。 force，如果没有f就会提示是否确认删除，有f就没有提示了。

## 7、dhclient命令而不是dhcp命令
DHCP（动态主机配置协议）是一个局域网的网络协议。指的是由服务器控制一段lP地址范围，客户机登录服务器时就可以自动获得服务器分配的lP地址和子网掩码。默认情况下，DHCP作为Windows Server的一个服务组件不会被系统自动安装，还需要管理员手动安装并进行必要的配置。 

## 8、chroot: failed to run command ‘/bin/bash’: No such file or directory
可以看下需要chroot的文件夹下bash命令的依赖
ldd ./dir/bin/bash

结果发现并不是一个可以chroot的目录。

## 9、linux系统中的i386/i686和x86_64有什么区别
Linux的的版本众多，包括服务器版本、桌面版本等，在下载安装镜像时候总会有i386/i686和x86_64这样的区别，带着疑问查了一下相关资料：

（1）参考一：http://blog.csdn.net/yandaqijian/article/details/41748759?locationNum=14点击打开链接

（2）参考二：http://blog.csdn.net/yandaqijian/article/details/41748599点击打开链接

总结来说：i386对应的是32位系统、而i686是i386的一个子集,i686仅对应P6及以上级别的CPU，i386则广泛适用于80386以上的各种CPU；x86_64主要是64位系统。

## 10、pactl 命令
https://www.linux-man.cn/command/pactl/

pactl命令可以修改伺服器的设置以及配置，但pactl命令仅限于局限的范围
若要完整的功能，就必須要回归到最基本的指令pacmd,通过pacmd指令才可以完全的控制PulseAudio的服务核心。
fedora24提供下列指令
pulseaudio - The PulseAudio Sound System
pactl - Control a running PulseAudio sound server
pacmd - Reconfigure a PulseAudio sound server during runtime

## 11、head命令
```
head -n 5 /etc/passwd       显示文件前五行，默认显示十行
head -n 2 /et/passwd /etc/shadow    可以同时查看两个文件前两行
tail -n 5 /etc/passwd       显示文件后五行
```
xrdb
$TERM

## 12、如何查看linux 文件内容换行符
cat -A 要查看的文件路径
或者使用vim打开你要查看的文件，在末行模式输入 :set list

使用cat -A可以清楚看见换行符是Windows格式还是unix格式，然后就可以使用unix2dos或者dos2unix进行转换。

## 13、查看Linux用的桌面是GNOME、KDE或者其他
ps aux | grep session
推荐使用ll /usr/bin/*session*命令

```
[root@ubuntu0006:/etc/network] #ll /usr/bin/*session*
-rwxr-xr-x 1 root root  10224 6月  12  2020 /usr/bin/dbus-run-session*
-rwxr-xr-x 1 root root   1059 3月  16  2016 /usr/bin/session-installer*
-rwxr-xr-x 1 root root 178448 5月  26  2015 /usr/bin/xfce4-session*
-rwxr-xr-x 1 root root  10672 5月  26  2015 /usr/bin/xfce4-session-logout*
-rwxr-xr-x 1 root root 108808 5月  26  2015 /usr/bin/xfce4-session-settings*
lrwxrwxrwx 1 root root     35 12月  7  2017 /usr/bin/x-session-manager -> /etc/alternatives/x-session-manager*
[root@ubuntu0006:/etc/network] #ps -A | egrep -i "gnome|kde|mate|cinnamon|lxde|xfce|jwm"
   16 ?        00:00:00 kdevtmpfs
 7178 ?        00:00:00 xfce4-terminal
 7198 ?        00:00:00 gnome-pty-helpe
14523 ?        00:00:00 gnome-keyring-d
15094 ?        00:00:00 xfce4-session
15106 ?        00:00:00 xfce4-panel
15113 ?        00:00:00 polkit-gnome-au
15121 ?        00:00:00 xfce4-volumed
15124 ?        00:00:00 xfce4-power-man
[root@ubuntu0006:/etc/network] #pgrep -l "gnome|kde|mate|cinnamon|lxde|xfce|jwm"
16 kdevtmpfs
7178 xfce4-terminal
7198 gnome-pty-helpe
14523 gnome-keyring-d
15094 xfce4-session
15106 xfce4-panel
15113 polkit-gnome-au
15121 xfce4-volumed
15124 xfce4-power-man
```
Xorg是图形界面的基础，任何桌面都需要Xorg的。

gdm是Linux的[图形界面](https://www.baidu.com/s?wd=图形界面&tn=SE_PcZhidaonwhc_ngpagmjz&rsv_dl=gh_pc_zhidao)
GDM (The GNOME Display Manager)是GNOME显示环境的管理器，并被用来替代原来的X Display Manager。与其竞争者(X3DM,KDM,WDM)不同，GDM是完全重写的，并不包含任何XDM的代码。GDM可以运行并管理本地和[远程登录](https://www.baidu.com/s?wd=远程登录&tn=SE_PcZhidaonwhc_ngpagmjz&rsv_dl=gh_pc_zhidao)的X服务器(通过XDMCP)。gdm仅仅是一个脚本，实际上是通过他来运行GDM二进制可执行文件。gdm-stop是用来迅速终止当前正在运行的gdm守护进程的一个脚本。gdm-restart脚本将迅速重启当前守护进程。然而gdm-safe-restart会当所有人都注销后再重启。gdmsetup是一种可以很简单的修改多数常用选项的图形化界面工具。GNOM的帮助里有更完整的文档，在“应用程序”/“系统工具”这一章节。 


 查了好久，有如下几种：
1、cat /etc/sysconfig/desktop ubuntu下不可用；
2、echo $DESKTOP_SESSION 貌似没有版本信息，而且不知道其他环境下效果怎样；
3、GNOME特性的查看版本命令：
gnome3版本以下使用下面可查：
gnome-panel --versionSample output:
GNOME gnome-panel 2.24.1Or type the following on modern gnome desktop systems:
$ gnome-about --gnome-version
Sample outputs:
Version: 2.30.2
Distributor: Debian
Build Date: Friday 12 November 2010
gnome3以上用以下命令Gnome 3.x user need to use the following command:
$ gnome-session --version
或者
gnome-shell --version
输出：
$ gnome-shell --version
GNOME Shell 3.4.1
但是这种无法查看其他的桌面版本。

## 14、后台运行
后台运行符号&
可以使用killall杀死，或者使用kill -9 pid
在运行开始后系统会通知该后台运行进程id

```
[root@ubuntu0006:/media/hankin/vdb] #./run_background.sh  &
[1] 13067
[root@ubuntu0006:/media/hankin/vdb] #ps aux| grep 13067
root     13067  0.0  0.0  15368  2976 pts/2    S    11:37   0:00 /bin/bash ./run_background.sh
root     14780  0.0  0.0  17088   964 pts/2    S+   11:38   0:00 grep --color=auto 13067
[root@ubuntu0006:/media/hankin/vdb] #tailf background
2021年 06月 23日 星期三 11:38:26 CST
2021年 06月 23日 星期三 11:38:27 CST
2021年 06月 23日 星期三 11:38:28 CST
2021年 06月 23日 星期三 11:38:29 CST
2021年 06月 23日 星期三 11:38:30 CST
^C
[root@ubuntu0006:/media/hankin/vdb] #killall run_background
run_background：没有发现操作
[root@ubuntu0006:/media/hankin/vdb] #killall run_background.sh
[1]+  已终止               ./run_background.sh
[root@ubuntu0006:/media/hankin/vdb] #tailf background
2021年 06月 23日 星期三 11:38:46 CST
2021年 06月 23日 星期三 11:38:47 CST
2021年 06月 23日 星期三 11:38:48 CST
2021年 06月 23日 星期三 11:38:49 CST
^C
[root@ubuntu0006:/media/hankin/vdb] #ps aux| grep 13067
root     18245  0.0  0.0  17088   928 pts/2    S+   11:38   0:00 grep --color=auto 13067
[root@ubuntu0006:/media/hankin/vdb] #cat run_background.sh
#!/bin/bash

while true; do
        echo `date` >> background
        sleep 1
done
```
## 15、再生龙
再生龙（Clonezilla）是一个免费的灾难恢复、硬盘克隆、硬盘映像档制作的部署和解决方案，由台湾的高速网络与计算中心所开发，以GNU通用公共许可协议（GPL）发布。
官网：https://clonezilla.nchc.org.tw/intro/
再生龙（Clonezilla）与Ghost的核心区别在于开源属性、系统兼容性和功能定位。再生龙是免费开源的跨平台备份工具，支持Linux、Windows、Mac等多系统及复杂文件系统，适合企业级批量操作；而Ghost是商业软件，以Windows系统为核心，提供更简化的分区管理和还原流程，更适合个人用户快速备份。

- 再生龙：由中国台湾开发的开源软件，遵循GPL协议，可免费使用和修改。
- Ghost：由Symantec开发的商业软件，需购买授权，主要面向Windows用户。

Clonezilla是一个用于Linux，Free-Net-OpenBSD，Mac OS X，Windows以及Minix的分区和磁盘克隆程序。它支持所有主要的文件系统，包括EXT，NTFS，FAT，XFS，JFS和Btrfs，LVM2，以及VMWare的企业集群文件系统VMFS3和VMFS5。Clonezilla支持32位和64位系统，同时支持旧版BIOS和UEFI BIOS，并且同时支持MBR和GPT分区表。它是一个用于完整备份Windows系统和所有安装于上的应用软件的好工具，而我喜欢用它来为Linux测试系统做备份，以便我可以在其上做疯狂的实验搞坏后，可以快速恢复它们。

Clonezilla也可以使用dd命令来备份不支持的文件系统，该命令可以复制块而非文件，因而不必在意文件系统。简单点说，就是Clonezilla可以复制任何东西。（关于块的快速说明：磁盘扇区是磁盘上最小的可编址存储单元，而块是由单个或者多个扇区组成的逻辑数据结构。）

其实就是一个Linux版的Ghost，甚至比Ghost还要强大，支持PXE进行批量还原，并且通杀Linux，Mac，Windows的系统文件格式。

克隆Linux不要使用ghost，它支持的格式分区有限。而且也不能完全克隆。
再生龙可以安装ISO文件。再生龙（CloneZilla）是一个开源的磁盘成像和备份还原工具，支持从ISO文件启动并进行系统备份和还原操作。

PS：下次装系统可以尝试使用再生龙试试。

## 16、其他
/lib /usr/lib /usr/local/lib 区别

添加/usr/local/lib默认库路径
echo “/usr/local/lib” >>/etc/ld.so.conf
/sbin/ldconfig

## 17、linux 2.6 support
2.6 时代跨度非常大，从2.6.0 (2003年12月发布[36]) 到 2.6.39(2011年5月发布), 跨越了 40 个大版本。
3.0(原计划的 2.6.40, 2011年7月发布) 到 3.19（2015年2月发布）。
4.0（2015年4月发布）到4.2（2015年8月底发布）。

总的来说，从进入2.6之后，每个大版本跨度开发时间大概是 2 - 3 个月。2.6.x , 3.x, 4.x，数字的递进并没有非常根本性，非常非常非常引人注目的大变化，但每个大版本中都有一些或大或小的功能改变。主版本号只是一个数字而已。不过要直接从 2.6.x 升级 到 3.x, 乃至 4.x，随着时间间隔增大，出问题的机率当然大很多。

个人觉得 Linux 真正走入严肃级别的高稳定性，高可用性，高可伸缩性的工业级别内核大概是在 2003 年后吧。一是随着互联网的更迅速普及，更多的人使用、参与开发。二也是社区经过11年发展，已经慢慢摸索出一套很稳定的协同开发模式，一个重要的特点是 社区开始使用版本管理工具进入管理，脱离了之前纯粹手工（或一些辅助的简陋工具）处理代码邮件的方式，大大加快了开发的速度和力度。

## 18、Linux查看BIOS版本/信息详情
命令如下：#dmidecode -t 0


## 19、
/etc/rc.local

/dev/bus/usb/
/sys/bus/usb/

apt install gnome-tweaks  安装完后需要重启物理机才能出现额外的选项。


输入法框架： 小企鹅输入法框架内（fcitx)
root@hankin:~# apt show fcitx

软键盘可选项：florence
安装 apt install florence
root@hankin:~# apt show florence

命令行启动florence: florence &
命令行调出软键盘： florence show
命令行隐藏软键盘： florence hide
软键盘与实体键盘在一个层级，中英文输入由输入框架控制


windows的ico图标转换为linux的png图标的小工具印象中似乎有不少，我觉得有icotool这个就够用了。

安装：
sudo apt-get install icoutils

用法：
#将当前文件夹下所有ico文件中的48x48图像，一下子全部提取出来放到48文件夹中
icotool -x -o 48 -w 48 *.ico 

## 20、需求将样本数据从文件夹分成两半
- 使用shell中的cp命令拷贝成两半
- 还有一种方法是python的os.walk时只遍历指定头部的文件
- 还有一种方法是计数，但是每次os.walk的时候是否一致（反正肯定会存储两个csv文件中，然后分析一下是否存在重复，个人感觉没有重复）

```
[root@ubuntu0006:/media/hankin/vdb/study] #ll test/ | wc
     12     101     788
[root@ubuntu0006:/media/hankin/vdb/study] #ls test/ | wc
      9       9     145
[root@ubuntu0006:/media/hankin/vdb/study/test] #ll ['i','m']*
-rwxr-xr-x 1 root root    859 7月   7  2021 if_for_while.sh*
-rw-r--r-- 1 root root 838731 6月  30  2021 mpc-1.2.1.tar.gz
[root@ubuntu0006:/media/hankin/vdb/study/test] #ll [a-m]*
-rwxr-xr-x 1 root root     43 6月  29  2021 echo_HOME_value.sh*
-rwxr-xr-x 1 root root    859 7月   7  2021 if_for_while.sh*
-rw-r--r-- 1 root root 838731 6月  30  2021 mpc-1.2.1.tar.gz
```

## 21、通过源码安装完命令后却报错找不到
原因是默认安装到/usr/local/bin目录，命令查找目录为/usr/bin/。
可以通过修改PATH值来解决。
注意：PATH值是从左到右进行覆盖，取最右的值。
```
[root@ubuntu0006:/media/hankin/vdb/TransferStation] #echo $PATH
/usr/local/sbin/:/usr/local/bin/:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin
[root@ubuntu0006:/media/hankin/vdb/TransferStation] #rm /usr/bin/gdb
[root@ubuntu0006:/media/hankin/vdb/TransferStation] #gdb
-bash: /usr/bin/gdb: 没有那个文件或目录
[root@ubuntu0006:/media/hankin/vdb/TransferStation] #export PATH=$PATH:/usr/local/bin/
[root@ubuntu0006:/media/hankin/vdb/TransferStation] #gdb
GNU gdb (GDB) 8.2.1
Copyright (C) 2018 Free Software Foundation, Inc.
License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.
Type "show copying" and "show warranty" for details.
This GDB was configured as "x86_64-pc-linux-gnu".
Type "show configuration" for configuration details.
For bug reporting instructions, please see:
<http://www.gnu.org/software/gdb/bugs/>.
Find the GDB manual and other documentation resources online at:
    <http://www.gnu.org/software/gdb/documentation/>.

For help, type "help".
Type "apropos word" to search for commands related to "word".
(gdb) q
[root@ubuntu0006:/media/hankin/vdb/TransferStation] #echo $PATH
/usr/local/sbin/:/usr/local/bin/:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/usr/local/bin/
```

```
\          SORRY            /
 \                         /
  \    This page does     /
   ]   not exist yet.    [    ,'|
   ]                     [   /  |
   ]___               ___[ ,'   |
   ]  ]\             /[  [ |:   |
   ]  ] \           / [  [ |:   |
   ]  ]  ]         [  [  [ |:   |
   ]  ]  ]__     __[  [  [ |:   |
   ]  ]  ] ]\ _ /[ [  [  [ |:   |
   ]  ]  ] ] (#) [ [  [  [ :===='
   ]  ]  ]_].nHn.[_[  [  [
   ]  ]  ]  HHHHH. [  [  [
   ]  ] /   `HH("N  \ [  [
   ]__]/     HHH  "  \[__[
   ]         NNN         [
   ]         N/"         [
   ]         N H         [
  /          N            \
 /           q,            \
/                           \
```

## 22、命令返回值
使用反引号（``）包裹命令时，Shell会尝试执行反引号中的内容，并将其结果作为命令的参数。
等价于（$()）包裹命令。
注意：有时候中间会有空格出现，需要外面再裹一层双引号，如：
```
[root@ubuntu0006:~/cmake] #date -d $(date +'%Y%m%d %H:%M:%S') +%s
date: 额外的操作数 "+%s"
Try 'date --help' for more information.
[root@ubuntu0006:~/cmake] #date -d "$(date +'%Y%m%d %H:%M:%S')" +%s
1700537669
```



