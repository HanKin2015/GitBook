# Linux系统中默认的全局变量

# 1、查看当前是否为root用户

> echo $UID        root用户为0，其他用户为其他

> #### 其他全局变量（可以使用tab键查看）
>
> - EUID
> - USER
> - PATH
> - DEVICE
> - HOME
> - PWD
> - _
> - SHELL