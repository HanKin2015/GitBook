# Linux ln命令

## 1、简介
Linux ln命令是一个非常重要命令，它的功能是为某一个文件在另外一个位置建立一个同步的链接。

当我们需要在不同的目录，用到相同的文件时，我们不需要在每一个需要的目录下都放一个必须相同的文件，我们只要在某个固定的目录，放上该文件，然后在 其它的目录下用ln命令链接（link）它就可以，不必重复的占用磁盘空间。

## 2、命令功能 
Linux文件系统中，有所谓的链接(link)，我们可以将其视为档案的别名，而链接又可分为两种 : 硬链接(hard link)与软链接(symbolic link)，硬链接的意思是一个档案可以有多个名称，而软链接的方式则是产生一个特殊的档案，该档案的内容是指向另一个档案的位置。硬链接是存在同一个文件系统中，而软链接却可以跨越不同的文件系统。

不论是硬链接或软链接都不会将原本的档案复制一份，只会占用非常少量的磁碟空间。

## 3、软链接
1.软链接，以路径的形式存在。类似于Windows操作系统中的快捷方式
2.软链接可以 跨文件系统 ，硬链接不可以
3.软链接可以对一个不存在的文件名进行链接
4.软链接可以对目录进行链接

## 4、硬链接
1.硬链接，以文件副本的形式存在。但不占用实际空间。
2.不允许给目录创建硬链接
3.硬链接只有在同一个文件系统中才能创建

## 5、命令参数

### 5-1、必要参数
```
-b 删除，覆盖以前建立的链接
-d 允许超级用户制作目录的硬链接
-f 强制执行
-i 交互模式，文件存在则提示用户是否覆盖
-n 把符号链接视为一般目录
-s 软链接(符号链接)
-v 显示详细的处理过程
```

### 5-2、选择参数
```
-S "-S<字尾备份字符串> "或 "--suffix=<字尾备份字符串>"
-V "-V<备份方式>"或"--version-control=<备份方式>"
--help 显示帮助信息
--version 显示版本信息
```

## 6、实例
给文件创建软链接，为log2013.log文件创建软链接link2013，如果log2013.log丢失，link2013将失效：
```
>ln -s log2013.log link2013   软链接
```

感觉可以理解硬链接就是复制。
```
>ln log2013.log link2013   硬链接
```

```
[root@localhost test]# ll
lrwxrwxrwx 1 root root     11 12-07 16:01 link2013 -> log2013.log
-rw-r--r-- 2 root bin      61 11-13 06:03 ln2013
-rw-r--r-- 2 root bin      61 11-13 06:03 log2013.log

注意硬链接只能创建文件：
[root@ubuntu0006:~/cmake] #ln -d /root/cmake/hj jl
ln: 无法创建硬链接'jl' => '/root/cmake/hj': 不允许的操作
[root@ubuntu0006:~/cmake] #ln /root/cmake/hj jl
ln: /root/cmake/hj: 不允许将硬链接指向目录
[root@ubuntu0006:~/cmake] #ln /root/cmake/hj/ jl
en_US.po  locale/   msg.pot   test.sh   zh_CN.po
[root@ubuntu0006:~/cmake] #ln /root/cmake/hj/test.sh jl
[root@ubuntu0006:~/cmake] #ln -d /root/cmake/hj/test.sh jm
```

## 7、Linux删除软链接的正确方式
```
# 假设软链接是文件夹
# 正确，只删除软链接，不删除教链接对应的文件夹下的数据
rm appuploadfiles

# 没事!文件夹删不掉
rm appuploadfiles/

#危险!!!这会把这个软链接对应的文件夹下的文件都删除掉! ! !
rm -rf appuploadfiles/
```







