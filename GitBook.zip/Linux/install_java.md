# 安装java环境

## 1、下载javaJDK
https://www.oracle.com/cn/java/technologies/javase-jdk15-downloads.html

Xubuntu选择：Linux x64 Compressed Archive


## 安装包
tar zxvf

mv  /opt
cd /bin
ln -s /opt/jdk java
java -version




1048632019202114

104861201902003918

