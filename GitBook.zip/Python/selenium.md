# 学习selenium

## 1、环境准备
使用selenium，安装conda install selenium

下载chrome驱动文件：
https://registry.npmmirror.com/binary.html?path=chromedriver/
http://chromedriver.storage.googleapis.com/index.html

如果打开Ie或Chrome浏览器，需要先将驱动文件放到python根目录下(C:\Users\Administrator\Anaconda3\Scripts)，或者在代码中指定位置。
- chromedriver.exe
- IEDriverServer.exe

打开Firefox浏览器则不需要这个操作。

注意：
1.Firefox浏览器47.0版本会报错，安装46.0以下版本（勿升级）
2.取消Ie浏览器保护模式

## 2、demo演示

```

```












