# 蓝奏云之程序自主更新

参考：https://www.jianshu.com/p/079662967b38

## 1、Python使用Requests和BS4实现蓝奏云直链解析与下载
示例文件分享地址：https://wwe.lanzoui.com/iabrphqxs0j

静态获取：
F12-》左上角箭头-》选择红色下载按钮-》在a herf中就是下载链接

动态获取：
F12-》选择Network-》右上角三点可以控制一个Name框-》选择ajaxm.php-》右边就是下载链接

## 2、传文件找文叔叔
https://www.wenshushu.cn/







