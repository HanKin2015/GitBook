# exec函数

## 1、Python `exec` 命令在函数内执行无效的解决办法
参考：https://blog.csdn.net/m0_60862600/article/details/125002232

不是很推荐，会影响执行效率。

如果对效率不在意可以使用。











