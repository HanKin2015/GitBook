# 生成和识别二维码

## 百度大部分是使用zxing库
下载https://pypi.org/project/zxing/

参考：https://www.jianshu.com/p/5d57651a7598

折腾了半天，最终zxing没有使用成功。





最终可行方案：https://www.cnblogs.com/xushengming/p/9872061.html











