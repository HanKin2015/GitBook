# 使用python ftplib递归删除FTP文件夹内所有内容

最开始简单的使用删除文件命令，发现文件夹删除不了报错。然后使用删除文件夹命令，后来又发现不为空的文件夹删除不了报错。

参考：https://blog.csdn.net/weixin_44421339/article/details/104016615?utm_medium=distribute.pc_relevant.none-task-blog-title-2&spm=1001.2101.3001.4242


ftplib是python中自带的默认库
可以使用它连接、操作ftp服务器相关的内容



