# 使用Python来写mock代码

https://blog.csdn.net/kami_ochin_akane/article/details/108876047