# 爬虫小练习


# 1、爬取方正驱动网信息
爬取网站：http://www.foundertech.com/drivers/list_369.html




# 2、爬取百度百科






# 3、域名备案爬取



# 4、爬取长沙房地产开发商房屋销售情况
越秀亲邻雅苑（越秀亲爱里）：http://www.cszjxx.net/floorinfo/202004160830
中冶天润菁园三期（中冶中央公园）：http://www.cszjxx.net/floorinfo/202005070287
依云曦府：http://www.cszjxx.net/floorinfo/202006230442

使用pandas的read_html函数一步抓取表格数据，简单方便快捷。
但是遇到瓶颈，展开户室列表是使用js写的，动态加载。详细见crawler_display_none.md文章。





















