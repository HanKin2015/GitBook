# 研究专研

[当代硕博生常犯错觉大赏：我的idea非常棒，别人肯定想不到！]( https://mp.weixin.qq.com/s/RYgH86s-1w6df2O3J4B6wA )

[深信服内部推荐攻略]( https://mp.weixin.qq.com/s?__biz=MjM5MzQzNTc1MA==&mid=503345404&idx=1&sn=bb41af6193a2126bb311bd578762151c&chksm=3d63c9f50a1440e39fbe8a815effa5b931999c745913fa327c7a9df9be31bdbd08dccbea500c&mpshare=1&scene=23&srcid=0726VE56uQ9N0c4S463veJ0c&sharer_sharetime=1571811846242&sharer_shareid=1324268725a3f629731d8a416eaa436e#rd )

