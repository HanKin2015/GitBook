# mac学习

## 1、mac查看网卡连接的网线是百兆还是千兆
ifconfig即可查看到想知道的答案：
```
media: autoselect (1000baseT <full-duplex>)
```
