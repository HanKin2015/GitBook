# PPT学习笔记

## 1、第一PPT免费下载
https://www.1ppt.com/

[史上最全免费PPT模板资源下载网站推荐](https://zhuanlan.zhihu.com/p/125744980?utm_source=wechat_session)

[PPT下载站](https://ypppt.com/)

推荐：[优品PPT](https://www.ypppt.com/article/2015/881.html)

## 2、字体选择

### 等宽字体
- consolas
- JetBrainsMono：https://www.jetbrains.com/lp/mono/

## 3、ppt如何插入实时日期
插入-》日期和时间
