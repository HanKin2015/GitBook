# Windows7系统鼠标右键一直转圈圈

pchunter64.exe

procexp.exe

任务管理器

性能管理器


