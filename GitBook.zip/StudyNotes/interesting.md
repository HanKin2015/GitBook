# 有趣的灵魂

有趣的7个网站

- [恐龙快跑]([chrome://dino/](chrome://dino/))
- [系统假装升级](https://fakeupdate.net)
- [四大名著的地图](https://www.sdmz.net/map)
- [网页版扫雷](https://www.saolei.org)
- [在线迷宫](http://www.mazegenerator.net/)
- [在线贪吃蛇](http://slither.io/)
- [在线连连看](https://lines.frvr.com/)