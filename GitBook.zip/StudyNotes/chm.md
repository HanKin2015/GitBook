# chm

## 1、简介
CHM 文件格式是微软于 1998 年推出的基于 HTML 文件特性的帮助文件系统，以替代早先的 WinHelp 帮助系统。它在 Windows 98 中把 CHM 类型文件称作“编译的 HTML 帮助文件”（Compiled HTML Help file）。
被 IE 浏览器支持的JavaScript, VBScript, ActiveX, Java Applet, Flash, 常见图形文件(GIF、JPEG、PNG)、音频视频文件(MID、WAV、AVI)等等，CHM同样支持，并可以通过 URL 与 Internet 联系在一起。
CHM 文件因为使用方便，形式多样，也被采用作为电子书的格式。

## 2、制作工具简介
关于制作 CHM 文件的工具，我们可以使用微软的 HTML Help Workshop(以下简称HHW)或者“国华软件工作室”的 eTextWizard (电子文档处理器，以下简称EW)。HHW 在 VB、 VC 等开发工具的 CD 中都有，也可以到微软的站点去下载最新版本，互联网上也可以找到汉化的版本。EW 是国人开发的软件，使用上要方便一些。

https://jingyan.baidu.com/article/bad08e1ed644d309c85121c1.html

使用Mybase软件就可以直接导出chm文件。

## 3、Windows10打开chm文件无内容只有目录
但是换了一台电脑能正常显示。

解决方案，解除 Internet Explorer 安全限制：
将 CHM 文件复制到本地磁盘上。
右键点击 CHM 文件，选择“属性”。
在“常规”选项卡中，如果有“解除锁定”复选框，勾选它以解除文件的安全限制。
双击打开 CHM 文件，如果出现提示，选择“允许”以解除 Internet Explorer 的安全限制。






