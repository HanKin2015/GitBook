
# 脚本学习总结

## python

- 文件分类
- 生成md文件目录
- gitbook生成summary.md文件
- python操作ftp

## shell
- 入参赋值
- 读取文件赋值

## js

## 





























