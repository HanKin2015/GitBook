# Coggle数据科学
Coggle全称Communication For Kaggle，专注数据科学领域竞赛相关资讯分享。

欢迎关注Coggle数据科学，近期比赛链接汇总：
https://coggle.club/

比赛baseline分享：
https://github.com/datawhalechina/competition-baseline

Kaggle2022年度竞赛年鉴：https://cdn.coggle.club/kaggle-2022.pdf

Kaggle在线学习路线：https://coggle.club/blog/kaggle-roadmap
