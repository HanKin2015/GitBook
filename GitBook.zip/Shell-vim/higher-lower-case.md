# 大小写转换

tmp="abcDEF"

delcare -l ret1=$tmp

delcare -u ret2=$tmp

>ret1=abcdef
>
>ret2=ABCDEF











