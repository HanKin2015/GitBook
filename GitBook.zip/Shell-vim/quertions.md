# shell编程中遇到的问题

# 1、#!/bin/bash没有那个文件或目录
这个原因就是Windows和Linux的换行符或者编码问题，使用：
dos2unix和unix2dos

