# Go和C/C++之间互相调用

厉害了高教授，https://book.douban.com/subject/23759678/

## Lighttpd源码分析
《Lighttpd源码分析》是2010年机械工业出版社出版的图书，作者是高群凯。


C/C++调Go函数

https://stackoverflow.com/questions/6125683/call-go-functions-from-c

https://medium.com/learning-the-go-programming-language/calling-go-functions-from-other-languages-4c7d8bcc69bf

C/C++调用Golang 一 https://www.cnblogs.com/majianguo/p/7486812.html
C和Go相互调用 https://colobu.com/2018/08/28/c-and-go-calling-interaction/

Go调C/C++函数

https://stackoverflow.com/questions/37960425/using-c-in-a-go-application-for-performance

https://stackoverflow.com/questions/1713214/how-to-use-c-in-go








