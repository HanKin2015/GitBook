# 电视机

## 1、海信
Vidda

## 2、TCL
雷鸟

## 3、创维

## 当贝市场

## 酷喵VIP
酷喵是优酷授权的正版TV端应用，软件采用瀑布式页面，滑动即可浏览海量内容，软件具有视频分类功能，可以根据分类查找喜欢的视频，包括电视剧、电影、动漫、亲子、纪实、搞笑等分类，如果想精准查找视频，可以点击页面左上角的搜索按钮，输入视频名称即可查找。

酷喵VIP可以登录2台电视，一酷喵会员账号只允许本人最多在5个大屏设备上使用，且同一账号仅可2台设备同时观影。同一优酷会员账号，仅允许在手机端和pad端同时登录设备数不超过3个。

酷喵是优酷授权的正版TV端应用，软件采用瀑布式页面，滑动即可浏览海量内容，软件具有视频分类功能，可以根据分类查找喜欢的视频，包括电视剧、电影、动漫、亲子、纪实、搞笑等分类，如果想精准查找视频，可以点击页面左上角的搜索按钮，输入视频名称即可查找。

## 影视剧里的领衔主演、特别主演、特邀主演、特别出演、特邀出演、友情出演，有什么区别
https://zhidao.baidu.com/question/994389945228012059.html
https://baijiahao.baidu.com/s?id=1688211366552871662&wfr=spider&for=pc
影视剧里的领衔主演、特别主演、特邀主演、特别出演、特邀出演、友情出演的区别如下：领衔主演是主角，其他所有的都是配角，但是特别主演的咖位比较大。

一、领衔主演
领衔主演是第一主角，每部剧中会有一个或两个领衔主演，也就是所谓的男一号女一号，或者是近些年流行的双男主。他们是主演中的主演，整个剧情都是围绕他们来的，从第一集到最后一集，每一集都会出现，贯穿整部剧，是整部剧的主线。

二、联合主演
联合主演，就是把多个主演联合起来介绍。在一部剧里，戏份也比较重，但是多不过领衔主演。

三、特别主演
特别主演指在电影、电视剧或是舞台剧里，为了提高和保证票房或收视率，拜托比主演级别更高的演员来助演或者出演配角。特别主演的戏份不多，在电影中，一般不会超过5分钟。但是特别主演的这些演员，一方面能够在前期宣传上增加看点，另一方面是为了带新人，捧新人。

四、特邀主演
值得一提的是，特别主演和特邀主演的概念不同。
1、特邀主演是指特别邀请某人来参与演出，可以是大牌演员，也可以是有爆点的演员，还可以是群众演员。特别主演是虽不是特别邀请的，但必须是颇具名气的演员，甚至是比领衔主演的咖位还要高的演员来特别参与演出。
2、特邀主演是为了完成影视剧里特定任务而安排的角色，比如说为了迎合观众的喜好；特别主演则主要是为了提高和保证票房或收视率而安排的角色。

五、主演
主演就是不同于龙套的配角，有台词有剧情，为了不让领衔主演的故事单调，多会发生一些意料之外的故事，让领衔主演去处理和解决。

六、友情主演
友情主演简单解释就是邀请好朋友免费或者超低价出演。

总体上来讲，领衔主演是主角，其他所有的都是配角，但是特别主演的咖位比较大，这样就容易理解了。

## 电视盒子
tvbox和小苹果

```
以下为本人试过的配置资源，都可以使用。
1．http://刚刚.live/猫
2．https://agit.ai/Yoursmile7/TVBox/raw/branch/master/XC.json
3．https://agit.ai/767820774/TVBox3/raw/branch/main/tvbox
4．https://ghproxy.com/https://raw.githubusercontent.com/vpei/Free-TVUrl-Merge/main/out/tvbox.txt
5．https://ghproxy.com/https://raw.githubusercontent.com/tv-player/tvbox-line/main/tv/fj.json
6．https://agit.ai/z8126343/TVBox/raw/branch/master/xyh.json
7．https://agit.ai/youxia/TVBox/raw/branch/main/XC.json
8．https://agit.ai/Qingjin/TVBox/raw/branch/main/xh.json
9．https://神器每日推送.tk/pz.json
10．http://肥猫.love
11．学前教育、中小学教育http://www.yunwp.cn/api/v3/file/get/1093/1007.json?sign=kJ5EJJLNzf63QKB1ykTZwbbW9vnMfi-2Wjumk-wtL-E%3D%3A0
12．学习资源https://agit.ai/nbwzlyd/xiaopingguo/raw/branch/master/xiaopingguo/xiaopingguo.json
13．https://raw.iqiq.io/liu673cn/box/main/m.json
14．http://52bsj.vip:98/wuai
15．http://9xi4o.tk/0725.json
16．http://www.dmtv.ml/mao/single.json
17．http://111.67.196.181/mtv/meow.txt
18．https://ju.binghe.ga/4.txt
19．https://download.kstore.space/download/2883/m3u8/dsj/guochan/mp1/1.m3u8
20．http://52bsj.vip:81/api/v3/file/get/29899/box2.json?sign=3cVyKZQr3lFAwdB3HK-A7h33e0MnmG6lLB9oWlvSNnM%3D%3A0
21．http://pandown.pro/tvbox/tvbox.json
```




