# 使用QCamera实现切换相机、分辨率和图像捕获功能

## 1、说明
参考：https://blog.csdn.net/Star_ID/article/details/127195698

demo见：D:\Github\Storage\qt\c++\capture
程序见：百度网盘-》公司-》qt_c++-》capture.exe

## 2、









