# QString类型转换

## 1、QT的基础数据类型
https://blog.csdn.net/qq_15647227/article/details/83956078

## 2、