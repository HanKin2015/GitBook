# 解析zip文件中json文件数据

```
/* 使用7z.exe压缩文件或文件夹
 * 7zx64.exe a -tzip 压缩包名 压缩文件或文件夹 -r
 */
//system("7zx64.exe a -tzip -r 22 123");

/* 使用7z.exe解压缩文件
 * 7zx64.exe x -y 压缩包完整名 [-o222]指定输出文件夹
 */
//system("7zx64.exe x -y 22.zip -o222");
```