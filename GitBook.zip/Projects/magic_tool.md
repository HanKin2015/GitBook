
# magic_tool（初步叫魔法工具）


## magic_tool1.0实施
顺便实现一个托盘吧。



# 中文乱码
qt4以前是其他方法
qt5之后：
QString::fromLocal8Bit(“学生事务管理系统”); 

# 表格显示
# 读写文件
# 图片显示
# 坑
Windows记事本打开txt文件看都是正常





https://github.com/HanKin2015/fucking-algorithm
https://labuladong.gitbook.io/algo/
https://www.runoob.com/linux/linux-intro.html





# 其他










